import 'dart:async';
import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:careerapp/screens/PhotoGalleryDetailPage.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_image_slideshow/flutter_image_slideshow.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:sizer/sizer.dart';

import '../../../models/feed_model.dart';
import '../../../services/api_services.dart';
import 'expandable_text.dart';
import 'feed_report_sheets.dart';
import 'video_player_widget.dart';
import 'package:share_plus/share_plus.dart';

class FeedWidget extends StatefulWidget {
  final FeedItem feed;
  final String usedId;
  final String userName;
  final Function() notifyParent;
  const FeedWidget({
    Key? key,
    required this.feed,
    required this.notifyParent,
    required this.usedId,
    required this.userName,
  }) : super(key: key);

  @override
  State<FeedWidget> createState() => _FeedWidgetState();
}

class _FeedWidgetState extends State<FeedWidget> {
  FeedItem feed = FeedItem();
  TextEditingController commentCntrlr = TextEditingController();
  int likeCount = 0;
  bool isLiked = false;
  bool isBookmarked = false;
  bool showCommentSection = false;

  @override
  void initState() {
    feed = widget.feed;
    likeCount = int.parse(feed.likesCount!.totalLikes!);
    super.initState();
  }

  void _sharePost() async {
    String postTitle = widget.feed.title ?? "Check this out!";
    String postBody = widget.feed.body ?? "";
    String postUrl = widget.feed.image != null && widget.feed.image!.isNotEmpty
        ? widget.feed.image!.first
        : "";

    String shareContent = "$postTitle\n\n$postBody\n\n$postUrl";

    await Share.share(shareContent);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 1.5.h),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey.shade200, width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header Section
          _buildHeaderSection(),
          
          // Media Section
          _buildMediaSection(),
          
          // Action Buttons Section
          _buildActionButtons(),
          
          // Likes Count
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            child: Text(
              '$likeCount likes',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 11.sp,
              ),
            ),
          ),
          
          // Caption Section
          _buildCaptionSection(),
          
          // Comments Preview
          _buildCommentsPreview(),
          
          // Post Time
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            child: Text(
              timeAgoCustom(
                feed.scheduled_at.toString() == '0000-00-00 00:00:00'
                    ? DateTime.parse(feed.createdAt.toString())
                    : DateTime.parse(feed.scheduled_at.toString()),
              ),
              style: TextStyle(
                fontSize: 10.sp,
                color: Colors.grey.shade600,
              ),
            ),
          ),
          
          // Add Comment Section
          _buildAddCommentSection(),
          
          // Interest Buttons
          _buildInterestButtons(),
          
          SizedBox(height: 1.h),
        ],
      ),
    );
  }

  Widget _buildHeaderSection() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
      child: Row(
        children: [
          // Profile Picture
          Container(
            width: 8.w,
            height: 8.w,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.pink, width: 1.5),
              gradient: const LinearGradient(
                colors: [
                  Colors.purple,
                  Colors.pink,
                  Colors.orange,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            padding: EdgeInsets.all(0.3.w),
            child: CircleAvatar(
              backgroundColor: Colors.white,
              child: CircleAvatar(
                radius: 3.5.w,
                backgroundImage: const AssetImage("assets/profileimg.png"),
              ),
            ),
          ),
          
          SizedBox(width: 3.w),
          
          // Username and Post Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Career Defence School",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 12.5.sp,
                  ),
                ),
                Row(
                  children: [
                    Text(
                      feed.postCategoryName!,
                      style: TextStyle(
                        fontSize: 11.sp,
                        color: Colors.grey.shade600,
                      ),
                    ),
                    SizedBox(width: 1.w),
                    Text(
                      '•',
                      style: TextStyle(
                        fontSize: 11.sp,
                        color: Colors.grey.shade600,
                      ),
                    ),
                    // SizedBox(width: 1.w),
                    // Text(
                    //   'Sponsored',
                    //   style: TextStyle(
                    //     fontSize: 8.sp,
                    //     color: Colors.blue.shade600,
                    //     fontWeight: FontWeight.w500,
                    //   ),
                    // ),
                  ],
                ),
              ],
            ),
          ),
          
          // More Options Button
          IconButton(
            onPressed: () {
              _feedOtionsBottomSheetMenu();
            },
            icon: Icon(
              Icons.more_horiz,
              size: 6.w,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMediaSection() {
    if (feed.mediaType == 'image') {
      if (feed.image!.length > 1) {
        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => PhotoGalleryDetailPage(
                  imagePaths: feed.image,
                  currentIndex: 0,
                ),
              ),
            );
          },
          child: Stack(
            children: [
              ImageSlideshow(
                width: double.infinity,
                height: 50.h,
                initialPage: 0,
                indicatorColor: Colors.white,
                indicatorBackgroundColor: Colors.grey.withOpacity(0.5),
                children: feed.image!
                    .map((e) => CachedNetworkImage(
                          imageUrl: e,
                          fit: BoxFit.cover,
                          width: double.infinity,
                          height: 50.h,
                        ))
                    .toList(),
              ),
              if (feed.image!.length > 1)
                Positioned(
                  top: 2.h,
                  right: 4.w,
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '1/${feed.image!.length}',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 8.sp,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      } else {
        return GestureDetector(
          onDoubleTap: () => _handleDoubleTapLike(),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => PhotoGalleryDetailPage(
                  imagePaths: feed.image,
                  currentIndex: 0,
                ),
              ),
            );
          },
          child: Container(
            color: Colors.black,
            height: 50.h,
            child: CachedNetworkImage(
              imageUrl: feed.image![0],
              fit: BoxFit.contain,
              width: double.infinity,
              height: 50.h,
              placeholder: (context, url) => Container(
                color: Colors.grey.shade200,
                child: const Center(child: CircularProgressIndicator(color: Colors.pink)),
              ),
              errorWidget: (context, url, error) => Container(
                color: Colors.grey.shade200,
                child: const Icon(Icons.error, color: Colors.grey),
              ),
            ),
          ),
        );
      }
    } else {
      return CustomVideoPlayer(
        play: false,
        feedItem: feed,
        userId: widget.usedId,
        userName: widget.userName,
      );
    }
  }

  Widget _buildActionButtons() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              // Like Button
              _buildAnimatedIconButton(
                icon: isLiked ? Icons.favorite : Icons.favorite_border,
                color: isLiked ? Colors.red : Colors.black,
                onTap: _handlePostLike,
              ),
              SizedBox(width: 4.w),
              
              // Comment Button
              _buildIconButton(
                icon: Icons.chat_bubble_outline,
                onTap: () {
                  setState(() {
                    showCommentSection = !showCommentSection;
                  });
                },
              ),
              SizedBox(width: 4.w),
              
              // Share Button
              _buildIconButton(
                icon: FontAwesomeIcons.paperPlane,
                onTap: _sharePost,
              ),
            ],
          ),
          
          // Bookmark Button
          _buildIconButton(
            icon: isBookmarked ? Icons.bookmark : Icons.bookmark_border,
            onTap: () {
              setState(() {
                isBookmarked = !isBookmarked;
              });
              Fluttertoast.showToast(
                msg: isBookmarked ? "Post saved" : "Post removed",
              );
            },
          ),
        ],
      ),
    );
  }

 Widget _buildCaptionSection() {
  return Padding(
    padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.5.h),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (feed.title!.isNotEmpty)
          Padding(
            padding: EdgeInsets.only(bottom: 0.5.h),
            child: Text(
              feed.title!,
              style: TextStyle(
                fontSize: 13.5.sp,
                fontWeight: FontWeight.bold,
                height: 1.25,
              ),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ReadMoreText(
          feed.body!,
          trimLines: 2, // This should work without trimMode
          colorClickableText: Colors.blue,
          trimCollapsedText: ' Read more',
          trimExpandedText: ' Show less',
          textAlign: TextAlign.start,
          style: TextStyle(
            fontSize: 12.5.sp,
            height: 1.35,
            color: Colors.black87,
          ),
          moreStyle: TextStyle(
            fontSize: 12.5.sp,
            color: Colors.blue,
            fontWeight: FontWeight.bold,
          ),
          lessStyle: TextStyle(
            fontSize: 12.5.sp,
            color: Colors.blue,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    ),
  );
}

  Widget _buildCommentsPreview() {
    if (feed.comments == null || feed.comments!.isEmpty) {
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: 4.w),
        child: Text(
          'No comments yet',
          style: TextStyle(
            fontSize: 12.sp,
            color: Colors.grey.shade600,
            fontStyle: FontStyle.italic,
          ),
        ),
      );
    }

    return Column(
      children: [
        if (feed.comments!.length > 2 && !showCommentSection)
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w),
            child: GestureDetector(
              onTap: () {
                setState(() {
                  showCommentSection = true;
                });
              },
              child: Text(
                'View all ${feed.comments!.length} comments',
                style: TextStyle(
                  fontSize: 12.sp,
                  color: Colors.grey.shade600,
                ),
              ),
            ),
          ),
        
        if (showCommentSection || feed.comments!.length <= 2)
          ...feed.comments!.take(showCommentSection ? feed.comments!.length : 2).map((comment) {
            return _buildCommentItem(comment);
          }).toList(),
      ],
    );
  }

  Widget _buildCommentItem(FeedComment comment) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.5.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 3.w,
            backgroundColor: Colors.grey.shade300,
            backgroundImage: const AssetImage("assets/profileimg.png"),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: comment.userName!,
                        style: TextStyle(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      TextSpan(
                        text: ' ${comment.comment!}',
                        style: TextStyle(
                          fontSize: 12.sp,
                          color: Colors.black87,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 0.3.h),
                Row(
                  children: [
                    Text(
                      '2h',
                      style: TextStyle(
                        fontSize: 10.5.sp,
                        color: Colors.grey.shade600,
                      ),
                    ),
                    SizedBox(width: 4.w),
                    Text(
                      'Like',
                      style: TextStyle(
                        fontSize: 10.5.sp,
                        color: Colors.grey.shade600,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(width: 4.w),
                    Text(
                      'Reply',
                      style: TextStyle(
                        fontSize: 10.5.sp,
                        color: Colors.grey.shade600,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.favorite_border,
              size: 4.w,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddCommentSection() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        border: Border(top: BorderSide(color: Colors.grey.shade200, width: 0.5)),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 3.5.w,
            backgroundColor: Colors.grey.shade300,
            backgroundImage: const AssetImage("assets/profileimg.png"),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: TextField(
              controller: commentCntrlr,
              style: TextStyle(fontSize: 12.sp),
              decoration: InputDecoration(
                hintText: 'Add a comment...',
                hintStyle: TextStyle(
                  fontSize: 12.sp,
                  color: Colors.grey.shade600,
                ),
                border: InputBorder.none,
                contentPadding: EdgeInsets.zero,
              ),
            ),
          ),
          SizedBox(width: 3.w),
          GestureDetector(
            onTap: () async {
              if (widget.usedId.isNotEmpty) {
                if (commentCntrlr.text.isNotEmpty) {
                  await _handleCommentPost(commentCntrlr.text);
                } else {
                  Fluttertoast.showToast(
                    msg: "Enter comment.",
                    timeInSecForIosWeb: 10,
                  );
                }
              } else {
                Fluttertoast.showToast(
                  msg: "Log in to comment",
                  timeInSecForIosWeb: 10,
                );
              }
            },
            child: Text(
              'Post',
              style: TextStyle(
                fontSize: 12.sp,
                color: commentCntrlr.text.isEmpty ? Colors.blue.shade300 : Colors.blue.shade600,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInterestButtons() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.5.h),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () {
                Fluttertoast.showToast(msg: "Marked as Not Interested");
              },
              icon: Icon(
                Icons.close,
                size: 4.w,
                color: Colors.red,
              ),
              label: Text(
                "Not Interested",
                style: TextStyle(
                  fontSize: 12.sp,
                  color: Colors.red,
                  fontWeight: FontWeight.w600,
                ),
              ),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.red),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: EdgeInsets.symmetric(vertical: 1.2.h),
              ),
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () {
                Fluttertoast.showToast(msg: "Marked as Interested");
              },
              icon: Icon(
                Icons.check,
                size: 4.w,
                color: Colors.green,
              ),
              label: Text(
                "Interested",
                style: TextStyle(
                  fontSize: 12.sp,
                  color: Colors.green,
                  fontWeight: FontWeight.w600,
                ),
              ),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.green),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: EdgeInsets.symmetric(vertical: 1.2.h),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIconButton({required IconData icon, required Function onTap}) {
    return GestureDetector(
      onTap: () => onTap(),
      child: Icon(
        icon,
        size: 6.w,
        color: Colors.black,
      ),
    );
  }

  Widget _buildAnimatedIconButton({
    required IconData icon,
    required Color color,
    required Function onTap,
  }) {
    return GestureDetector(
      onTap: () => onTap(),
      child: Icon(
        icon,
        size: 6.w,
        color: color,
      ),
    );
  }

  void _handleDoubleTapLike() {
    if (!isLiked) {
      setState(() {
        isLiked = true;
        likeCount++;
      });
      _handlePostLike();
    }
  }

  Future<Size> _calculateImageDimension() {
    Completer<Size> completer = Completer();
    Image image = const Image(
      image: CachedNetworkImageProvider(
          "https://i.stack.imgur.com/lkd0a.png"),
    );
    image.image.resolve(const ImageConfiguration()).addListener(
      ImageStreamListener(
        (ImageInfo image, bool synchronousCall) {
          var myImage = image.image;
          Size size = Size(myImage.width.toDouble(), myImage.height.toDouble());
          completer.complete(size);
        },
      ),
    );
    return completer.future;
  }

  imageSlider({required List<String> imageList}) {
    return ImageSlideshow(
      width: double.infinity,
      height: 30.h,
      isLoop: false,
      children: List<Widget>.generate(
        imageList.length,
        (index) {
          return CachedNetworkImage(
            imageUrl: imageList[index],
            fit: BoxFit.contain,
            height: 30.h,
          );
        },
      ),
    );
  }

  _handleCommentPost(String comment) async {
    var data = json.encode({
      'user_id': widget.usedId,
      'post_id': feed.id,
      'comment': comment,
    });

    try {
      var response2 = await ApiService.postMethod4(
        'Api/addComment',
        data,
      );

      if (response2["status"] == "1") {
        Fluttertoast.showToast(msg: "Comment Posted.", timeInSecForIosWeb: 10);
        FocusScope.of(context).requestFocus(FocusNode());
        setState(() {
          feed.comments!.add(
            FeedComment(comment: comment, userName: widget.userName),
          );
        });
        commentCntrlr.clear();
      }
    } catch (err) {
      if (kDebugMode) {
        print(err);
      }
    }
  }

  _handlePostLike() async {
    var data = json.encode({
      'user_id': widget.usedId,
      'post_id': feed.id,
    });

    try {
      var response2 = await ApiService.postMethod4(
        'Api/addLike',
        data,
      );
      if (response2["status"] == "1") {
        Fluttertoast.showToast(msg: "Liked", timeInSecForIosWeb: 10);
        setState(() {
          isLiked = true;
          likeCount++;
        });
      }
    } catch (err) {
      if (kDebugMode) {
        print(err);
      }
    }
  }

  _handlePostDisLike() async {
    var data = json.encode({
      'user_id': widget.usedId,
      'post_id': feed.id,
    });

    try {
      var response2 = await ApiService.postMethod4(
        'Api/addLike',
        data,
      );
      if (response2["status"] == "2") {
        Fluttertoast.showToast(msg: "Disliked", timeInSecForIosWeb: 10);
        setState(() {
          isLiked = false;
          likeCount--;
        });
      }
    } catch (err) {
      if (kDebugMode) {
        print(err);
      }
    }
  }

  void _feedOtionsBottomSheetMenu() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (builder) {
        return const FeedReportOptions();
      },
    );
  }

  String timeAgoCustom(DateTime d) {
    Duration diff = DateTime.now().difference(d);
    if (diff.inDays > 365) {
      return "${(diff.inDays / 365).floor()} ${(diff.inDays / 365).floor() == 1 ? "year" : "years"} ago";
    }
    if (diff.inDays > 30) {
      return "${(diff.inDays / 30).floor()} ${(diff.inDays / 30).floor() == 1 ? "month" : "months"} ago";
    }
    if (diff.inDays > 7) {
      return "${(diff.inDays / 7).floor()} ${(diff.inDays / 7).floor() == 1 ? "week" : "weeks"} ago";
    }
    if (diff.inDays > 1) {
      return "${diff.inDays} days ago";
    }
    if (diff.inDays == 1) {
      return "Yesterday";
    }
    if (diff.inHours > 0) {
      return "${diff.inHours} ${diff.inHours == 1 ? "hour" : "hours"} ago";
    }
    if (diff.inMinutes > 0) {
      return "${diff.inMinutes} ${diff.inMinutes == 1 ? "minute" : "minutes"} ago";
    }
    return "Just now";
  }
}
